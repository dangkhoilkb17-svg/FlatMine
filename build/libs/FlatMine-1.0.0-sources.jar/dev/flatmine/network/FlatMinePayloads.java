package dev.flatmine.network;

import net.minecraft.class_2338;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public final class FlatMinePayloads {
    public record Select(class_2338 pos) implements class_8710 { 
        public static final class_9154<Select> ID=new class_9154<>(class_2960.method_60655("flatmine","select")); 
        public static final class_9139<class_9129,Select> CODEC=class_9139.method_56434(class_2338.field_48404,Select::pos,Select::new); 
        public class_9154<? extends class_8710> method_56479(){return ID;} 
    }
    
    // Thêm boolean destroyDrops vào payload
    public record Action(int action, long maxBlocks, boolean destroyDrops) implements class_8710 { 
        public static final class_9154<Action> ID=new class_9154<>(class_2960.method_60655("flatmine","action")); 
        public static final class_9139<class_9129,Action> CODEC=class_9139.method_56436(
            class_9135.field_48550, Action::action,
            class_9135.field_48551, Action::maxBlocks,
            class_9135.field_48547, Action::destroyDrops, 
            Action::new
        ); 
        public class_9154<? extends class_8710> method_56479(){return ID;} 
    }
    
    public record Status(int kind, class_2338 a, class_2338 b, long blocks, int durability) implements class_8710 { 
        public static final class_9154<Status> ID=new class_9154<>(class_2960.method_60655("flatmine","status")); 
        public static final class_9139<class_9129,Status> CODEC=class_9139.method_56906(class_9135.field_48550,Status::kind,class_2338.field_48404,Status::a,class_2338.field_48404,Status::b,class_9135.field_48551,Status::blocks,class_9135.field_48550,Status::durability,Status::new); 
        public class_9154<? extends class_8710> method_56479(){return ID;} 
    }
    
    private FlatMinePayloads(){}
}