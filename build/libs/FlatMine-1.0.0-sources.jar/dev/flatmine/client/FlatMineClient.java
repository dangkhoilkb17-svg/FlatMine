package dev.flatmine.client;

import dev.flatmine.network.FlatMinePayloads;
import dev.flatmine.render.SelectionRenderer;
import dev.flatmine.screen.*;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.minecraft.block.*;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_2269;
import net.minecraft.class_2304;
import net.minecraft.class_2323;
import net.minecraft.class_2349;
import net.minecraft.class_2401;
import net.minecraft.class_2533;
import net.minecraft.class_2680;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;

public final class FlatMineClient implements ClientModInitializer {
    private boolean tutorialShown = false;

    @Override
    public void onInitializeClient() {
        class_304 cancel = KeyBindingHelper.registerKeyBinding(
            new class_304("key.flatmine.cancel", class_3675.class_307.field_1668, GLFW.GLFW_KEY_X, "category.flatmine")
        );
        class_304 settings = KeyBindingHelper.registerKeyBinding(
            new class_304("key.flatmine.settings", class_3675.class_307.field_1668, GLFW.GLFW_KEY_K, "category.flatmine")
        );

        UseBlockCallback.EVENT.register((p, w, h, hit) -> {
            if (!w.field_9236 || h != class_1268.field_5808) return class_1269.field_5811;
            if (!isTool(p.method_6047())) return class_1269.field_5811;
            
            class_2680 s = w.method_8320(hit.method_17777());
            if (s.method_26196(w, hit.method_17777()) != null || 
                s.method_26204() instanceof class_2323 || 
                s.method_26204() instanceof class_2533 || 
                s.method_26204() instanceof class_2349 || 
                s.method_26204() instanceof class_2269 || 
                s.method_26204() instanceof class_2401 || 
                s.method_26204() instanceof class_2304) {
                return class_1269.field_5811;
            }

            ClientPlayNetworking.send(new FlatMinePayloads.Select(hit.method_17777()));
            return class_1269.field_5812;
        });

        ClientPlayNetworking.registerGlobalReceiver(FlatMinePayloads.Status.ID, (payload, ctx) -> 
            ctx.client().execute(() -> handle(payload))
        );

        WorldRenderEvents.AFTER_TRANSLUCENT.register(SelectionRenderer::render);

        ClientTickEvents.END_CLIENT_TICK.register(c -> {
            while (cancel.method_1436()) {
                ClientState.clear();
                // ĐÃ SỬA: THÊM , false
                ClientPlayNetworking.send(new FlatMinePayloads.Action(0, ClientState.maxBlocks, false));
                c.method_1507(null);
            }
            while (settings.method_1436()) {
                c.method_1507(new SettingsScreen(c.field_1755));
            }
            if (!tutorialShown && c.field_1724 != null) {
                tutorialShown = true;
                c.method_1507(new TutorialScreen());
            }
        });
    }

    static boolean isTool(net.minecraft.class_1799 s) {
        return s.method_31573(net.minecraft.class_3489.field_42614) || 
               s.method_31573(net.minecraft.class_3489.field_42615);
    }

    static void handle(FlatMinePayloads.Status p) {
        class_310 c = class_310.method_1551();
        if (p.kind() == 0) {
            ClientState.clear();
            return;
        }
        ClientState.a = p.a();
        ClientState.b = p.b();
        
        if (p.kind() == 2) {
            c.method_1507(new ConfirmScreen(p.blocks(), p.durability()));
        } else if (p.kind() == 3) {
            c.method_1507(new FinalConfirmScreen(p.blocks()));
        }
    }
}