package dev.flatmine.server;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_5321;
public final class SelectionState { public class_5321<class_1937> dimension; public class_2338 first, second; public void clear(){dimension=null;first=null;second=null;} }
