package dev.flatmine.server;
import net.minecraft.block.*;
import net.minecraft.class_2244;
import net.minecraft.class_2248;
import net.minecraft.class_2269;
import net.minecraft.class_2272;
import net.minecraft.class_2304;
import net.minecraft.class_2323;
import net.minecraft.class_2338;
import net.minecraft.class_2349;
import net.minecraft.class_2401;
import net.minecraft.class_2428;
import net.minecraft.class_2533;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3709;
import net.minecraft.class_3962;
public final class InteractiveBlocks {
 private InteractiveBlocks(){}
 public static boolean isInteractive(class_3218 world, class_2338 pos){
  class_2680 s=world.method_8320(pos); class_2248 b=s.method_26204(); class_2586 be=world.method_8321(pos);
  if(be!=null && s.method_26196(world,pos)!=null) return true;
  return b instanceof class_2304 || b instanceof class_2323 || b instanceof class_2533 || b instanceof class_2349 || b instanceof class_2269 || b instanceof class_2401 || b instanceof class_2244 || b instanceof class_2428 || b instanceof class_3709 || b instanceof class_2272 || b instanceof class_3962;
 }
}
