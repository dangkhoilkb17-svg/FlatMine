package dev.flatmine.server;

import dev.flatmine.common.Cuboid;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import net.minecraft.class_2338;
import net.minecraft.class_3218;
import net.minecraft.class_3222;

public final class MiningJob {
    private final class_3222 player;
    private final class_3218 world;
    private final Queue<class_2338> queue;
    private final boolean destroyDrops;

    public MiningJob(class_3222 p, class_3218 w, Cuboid c, boolean destroyDrops) {
        this.player = p;
        this.world = w;
        this.destroyDrops = destroyDrops;
        this.queue = new LinkedList<>();

        class_2338 minPos = new class_2338(c.minX(), c.minY(), c.minZ());
        class_2338 maxPos = new class_2338(c.maxX(), c.maxY(), c.maxZ());

        // BƯỚC 1: LẤY TOÀN BỘ CÁC BLOCK BỎ VÀO DANH SÁCH
        List<class_2338> list = new ArrayList<>();
        for (class_2338 pos : class_2338.method_10097(minPos, maxPos)) {
            if (!world.method_8320(pos).method_26215() && world.method_24794(pos)) {
                list.add(pos.method_10062());
            }
        }

        // BƯỚC 2: SẮP XẾP TỪ Y CAO XUỐNG Y THẤP (Để đào cuốn chiếu từ trên xuống)
        list.sort((p1, p2) -> Integer.compare(p2.method_10264(), p1.method_10264()));
        
        // BƯỚC 3: ĐƯA VÀO HÀNG ĐỢI
        queue.addAll(list);
    }

    public boolean tick() {
        if (player.method_31481() || player.method_37908() != world || !player.field_13974.method_14267()) {
            MiningJobManager.clearSelection(player); // Xóa viền sáng nếu người chơi chết hoặc đổi map
            return true; 
        }
        
        return MiningJobManager.processMiningTick(player, world, queue, 1.0f, destroyDrops);
    }

    public void cancel() {
        queue.clear();
    }
}