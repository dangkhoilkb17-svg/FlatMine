package dev.flatmine.server;

import dev.flatmine.common.Cuboid;
import dev.flatmine.network.FlatMinePayloads;
import java.util.*;
import java.util.Map.Entry;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_1263;
import net.minecraft.class_1304;
import net.minecraft.class_1799;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3222;

public final class MiningJobManager {
    private static final Map<UUID, MiningJob> JOBS = new HashMap<>();

    public static void init() {
        ServerTickEvents.END_SERVER_TICK.register(s -> {
            Iterator<Map.Entry<UUID, MiningJob>> it = JOBS.entrySet().iterator();
            while (it.hasNext()) {
                var e = it.next();
                if (e.getValue().tick()) {
                    it.remove();
                }
            }
        });
    }

    public static void startJob(class_3222 p, class_3218 w, Cuboid c, boolean destroyDrops) {
        cancelJob(p);
        JOBS.put(p.method_5667(), new MiningJob(p, w, c, destroyDrops));
    }

    public static void cancelJob(class_3222 p) {
        MiningJob j = JOBS.remove(p.method_5667());
        if (j != null) {
            j.cancel();
            clearSelection(p);
        }
    }

    public static boolean isRunning(class_3222 p) {
        return JOBS.containsKey(p.method_5667());
    }

    public static void clearSelection(class_3222 p) {
        if (p.field_13987 != null) {
            ServerPlayNetworking.send(p, new FlatMinePayloads.Status(0, class_2338.field_10980, class_2338.field_10980, 0, 0));
        }
    }

    public static boolean processMiningTick(class_3222 player, class_3218 world, Queue<class_2338> queue, float speedMultiplier, boolean destroyDrops) {
        class_1799 tool = player.method_6047();

        // 1. KIỂM TRA CÔNG CỤ
        if (!isPickaxeOrShovel(tool)) {
            player.method_7353(class_2561.method_43470("§c[FlatMine] Bị hủy: Bạn phải cầm Cúp hoặc Xẻng để tiếp tục đào!"), true);
            clearSelection(player);
            return true; 
        }

        int baseBlocksPerTick = 32; 
        int targetBreaks = Math.round(baseBlocksPerTick * speedMultiplier);
        int brokenCount = 0;

        // 2. VÒNG LẶP ĐÀO & TIÊU HỦY ĐỒ
        while (!queue.isEmpty() && brokenCount < targetBreaks) {
            class_2338 pos = queue.poll();
            var state = world.method_8320(pos);

            if (state.method_26215() || state.method_26214(world, pos) < 0) {
                continue;
            }

            class_2586 blockEntity = world.method_8321(pos);

            if (destroyDrops) {
                // Tiêu hủy sạch đồ chứa bên trong (rương, lò nung, hopper...)
                if (blockEntity instanceof class_1263 inv) {
                    inv.method_5448();
                }
                // Thay thế trực tiếp bằng Air không phát tín hiệu drop
                world.method_8652(pos, class_2246.field_10124.method_9564(), class_2248.field_31028 | class_2248.field_31031);
            } else {
                // Nhặt đồ bình thường khi không bật tiêu hủy
                class_2248.method_9511(state, world, pos, blockEntity, player, tool);
                world.method_8652(pos, class_2246.field_10124.method_9564(), class_2248.field_31028);
            }

            brokenCount++; 

            // 3. TRỪ ĐỘ BỀN
            int durabilityLoss = tool.method_7951(state) ? 1 : 2;

            if (!player.method_7337() && tool.method_7963()) {
                tool.method_7970(durabilityLoss, player, class_1304.field_6173);
                
                if (tool.method_7960()) {
                    player.method_7353(class_2561.method_43470("§c[FlatMine] Công cụ của bạn đã vỡ!"), true);
                    clearSelection(player);
                    return true; 
                }
            }
        }

        if (queue.isEmpty()) {
            player.method_7353(class_2561.method_43470("§a[FlatMine] Đã dọn dẹp xong khu vực!"), true);
            clearSelection(player);
            return true;
        }

        return false;
    }

    private static boolean isPickaxeOrShovel(class_1799 stack) {
        if (stack.method_7960()) return false;
        String name = stack.method_7909().method_7876();
        return name.contains("pickaxe") || name.contains("shovel");
    }

    private MiningJobManager() {}
}