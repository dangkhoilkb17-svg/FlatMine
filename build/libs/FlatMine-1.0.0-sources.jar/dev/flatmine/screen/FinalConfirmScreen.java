package dev.flatmine.screen;

import dev.flatmine.client.ClientState;
import dev.flatmine.network.FlatMinePayloads;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public final class FinalConfirmScreen extends class_437 {
    private final long blocks;

    public FinalConfirmScreen(long b) {
        super(class_2561.method_43470("Xác nhận cuối"));
        this.blocks = b;
    }

    @Override
    protected void method_25426() {
        method_37063(class_4185.method_46430(class_2561.method_43470("Bắt đầu đào"), b -> {
            // ĐÃ SỬA: THÊM , false
            ClientPlayNetworking.send(new FlatMinePayloads.Action(3, ClientState.maxBlocks, false));
            method_25419();
        }).method_46434(field_22789 / 2 - 105, field_22790 / 2, 100, 20).method_46431());
        method_37063(class_4185.method_46430(class_2561.method_43470("Hủy"), b -> {
            // ĐÃ SỬA: THÊM , false
            ClientPlayNetworking.send(new FlatMinePayloads.Action(0, ClientState.maxBlocks, false));
            method_25419();
        }).method_46434(field_22789 / 2 + 5, field_22790 / 2, 100, 20).method_46431());
    }

    @Override
    public void method_25394(class_332 c, int x, int y, float d) {
        super.method_25394(c, x, y, d);
        c.method_25300(field_22793, "Đào " + blocks + " block từ Y cao xuống Y thấp?", field_22789 / 2, 70, 0xFFFFFF);
    }
}