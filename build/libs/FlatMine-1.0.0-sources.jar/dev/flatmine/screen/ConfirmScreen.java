package dev.flatmine.screen;

import dev.flatmine.client.ClientState;
import dev.flatmine.network.FlatMinePayloads;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_4286;
import net.minecraft.class_437;

public final class ConfirmScreen extends class_437 {
    private final long blocks;
    private final int durability;
    private class_4286 destroyDropsCheckbox;

    public ConfirmScreen(long b, int d) {
        super(class_2561.method_43470("Xác nhận vùng"));
        this.blocks = b;
        this.durability = d;
    }

    @Override
    protected void method_25426() {
        int y = field_22790 / 2;
        
        // Thêm Checkbox lựa chọn tiêu hủy block (Mặc định: KHÔNG tiêu hủy)
        destroyDropsCheckbox = class_4286.method_54787(class_2561.method_43470("Tiêu hủy vật phẩm rơi ra (Chống lag)"), field_22793)
                .method_54789(field_22789 / 2 - 100, y - 30)
                .method_54794(false)
                .method_54788();
        method_37063(destroyDropsCheckbox);

        if (blocks > ClientState.maxBlocks) {
            method_37063(class_4185.method_46430(class_2561.method_43470("Thu nhỏ vùng"), x -> {
                ClientPlayNetworking.send(new FlatMinePayloads.Action(2, ClientState.maxBlocks, destroyDropsCheckbox.method_20372()));
                ClientState.clear();
                method_25419();
            }).method_46434(field_22789 / 2 - 155, y, 100, 20).method_46431());
            
            method_37063(class_4185.method_46430(class_2561.method_43470("Giữ nguyên"), x -> next()).method_46434(field_22789 / 2 - 50, y, 100, 20).method_46431());
            method_37063(class_4185.method_46430(class_2561.method_43470("Hủy"), x -> cancel()).method_46434(field_22789 / 2 + 55, y, 100, 20).method_46431());
        } else {
            // Trường hợp vùng hợp lệ, thêm nút Đào ngay trên màn hình này
            method_37063(class_4185.method_46430(class_2561.method_43470("Bắt đầu Đào"), x -> next()).method_46434(field_22789 / 2 - 105, y, 100, 20).method_46431());
            method_37063(class_4185.method_46430(class_2561.method_43470("Hủy"), x -> cancel()).method_46434(field_22789 / 2 + 5, y, 100, 20).method_46431());
        }
    }

    private void next() {
        boolean destroy = destroyDropsCheckbox != null && destroyDropsCheckbox.method_20372();
        if (blocks > durability && field_22787 != null) {
            // Lưu ý: Nếu mod của bạn có DurabilityScreen, bạn cũng cần cập nhật nó để gửi biến `destroy` lên server
            field_22787.method_1507(new DurabilityScreen(blocks)); 
        } else {
            ClientPlayNetworking.send(new FlatMinePayloads.Action(1, ClientState.maxBlocks, destroy));
            ClientState.clear(); // XÓA VIỀN SÁNG LẬP TỨC
            method_25419();
        }
    }

    private void cancel() {
        ClientPlayNetworking.send(new FlatMinePayloads.Action(0, ClientState.maxBlocks, false));
        ClientState.clear(); // XÓA VIỀN SÁNG LẬP TỨC
        method_25419();
    }

    @Override
    public void method_25394(class_332 c, int x, int y, float d) {
        super.method_25394(c, x, y, d);
        c.method_25300(field_22793, "Đã chọn " + blocks + " block.", field_22789 / 2, 60, 0xFFFFFF);
        if (blocks > ClientState.maxBlocks) {
            c.method_25300(field_22793, "Vùng đã chọn quá lớn và có thể gây lag.", field_22789 / 2, 82, 0xFFCC55);
        }
    }
}