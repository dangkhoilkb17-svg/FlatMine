package dev.flatmine.screen;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;
public final class TutorialScreen extends class_437 { public TutorialScreen(){super(class_2561.method_43470("FLATMINE"));} protected void method_25426(){method_37063(class_4185.method_46430(class_2561.method_43470("Đóng"),b->method_25419()).method_46434(field_22789/2-50,field_22790-40,100,20).method_46431());} public void method_25394(class_332 c,int mx,int my,float d){c.method_25294(0,0,field_22789,field_22790,0xE0101010);super.method_25394(c,mx,my,d);c.method_25300(field_22793,"FLATMINE",field_22789/2,28,0xFFFFFF);String[] l={"1. Cầm Pickaxe hoặc Shovel.","2. Right-click block thứ nhất để chọn góc 1.","3. Right-click block thứ hai để chọn góc 2.","4. Xác nhận để bắt đầu đào.","5. Mod đào từ Y cao xuống Y thấp.","6. X để hủy.","7. K để mở Settings."};for(int i=0;i<l.length;i++)c.method_25300(field_22793,l[i],field_22789/2,58+i*18,0xF2F2F2);} public boolean method_25421(){return false;} }
