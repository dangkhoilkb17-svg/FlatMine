package dev.flatmine.screen;

import dev.flatmine.client.ClientState;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_357;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public final class SettingsScreen extends class_437 {
    private final class_437 parent;
    private class_342 field;

    public SettingsScreen(class_437 p) {
        super(class_2561.method_43470("FlatMine Settings"));
        this.parent = p;
    }

    @Override
    protected void method_25426() {
        int centerX = field_22789 / 2;

        // Ô nhập số block tối đa
        field = new class_342(field_22793, centerX - 80, 45, 160, 20, class_2561.method_43470("Vùng xoá tối đa"));
        field.method_1852(Long.toString(ClientState.maxBlocks));
        method_37063(field);

        // Giá trị ban đầu cho Slider
        double initialSliderValue = (ClientState.miningSpeed == 2.0f) ? 1.0 : (ClientState.miningSpeed == 1.5f ? 0.5 : 0.0);

        // Thanh trượt chọn tốc độ 3 nấc
        method_37063(new class_357(centerX - 80, 90, 160, 20, getSpeedText(ClientState.miningSpeed), initialSliderValue) {
            @Override
            protected void method_25346() {
                method_25355(getSpeedText(getSnapSpeed(this.field_22753)));
            }

            @Override
            protected void method_25344() {
                if (this.field_22753 < 0.25) this.field_22753 = 0.0;
                else if (this.field_22753 < 0.75) this.field_22753 = 0.5;
                else this.field_22753 = 1.0;

                ClientState.miningSpeed = getSnapSpeed(this.field_22753);
            }
        });

        // Nút Lưu
        method_37063(class_4185.method_46430(class_2561.method_43470("Lưu"), b -> {
            try {
                ClientState.maxBlocks = Math.max(1, Long.parseLong(field.method_1882()));
            } catch (NumberFormatException ignored) {}
            method_25419();
        }).method_46434(centerX - 50, 150, 100, 20).method_46431());
    }

    private float getSnapSpeed(double val) {
        if (val >= 0.75) return 2.0f;
        if (val >= 0.25) return 1.5f;
        return 1.0f;
    }

    private class_2561 getSpeedText(float speed) {
        if (speed == 2.0f) return class_2561.method_43470("Tốc độ: 2.0x (Cực nhanh)");
        if (speed == 1.5f) return class_2561.method_43470("Tốc độ: 1.5x (Nhanh)");
        return class_2561.method_43470("Tốc độ: 1.0x (Gốc x2)");
    }

    @Override
    public void method_25419() {
        if (field_22787 != null) {
            field_22787.method_1507(parent);
        }
    }

    @Override
    public void method_25394(class_332 c, int x, int y, float d) {
        super.method_25394(c, x, y, d);
        int centerX = field_22789 / 2;

        c.method_25300(field_22793, "Vùng xoá tối đa (ngưỡng cảnh báo)", centerX, 30, 0xFFFFFF);
        c.method_25300(field_22793, "Tốc độ đào", centerX, 77, 0xFFFFFF);
        c.method_25300(field_22793, "(Cảnh báo: Tốc độ cao có thể gây giật lag server/máy)", centerX, 115, 0xFF5555);
    }
}