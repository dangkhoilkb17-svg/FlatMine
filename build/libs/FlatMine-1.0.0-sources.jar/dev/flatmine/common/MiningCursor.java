package dev.flatmine.common;
import net.minecraft.class_2338;
public final class MiningCursor {
 private final Cuboid c; private int x,z,y; private boolean done;
 public MiningCursor(Cuboid c){this.c=c; x=c.minX(); z=c.minZ(); y=c.maxY();}
 public boolean done(){return done;}
 public class_2338 current(){return done?null:new class_2338(x,y,z);}
 public void advance(){ if(done)return; if(++z<=c.maxZ())return; z=c.minZ(); if(++x<=c.maxX())return; x=c.minX(); if(--y>=c.minY())return; done=true; }
}
