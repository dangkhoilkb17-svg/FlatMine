package dev.flatmine.common;

import net.minecraft.class_2338;

public record Cuboid(int minX, int minY, int minZ, int maxX, int maxY, int maxZ) {
    public static Cuboid of(class_2338 a, class_2338 b) {
        return new Cuboid(Math.min(a.method_10263(), b.method_10263()), Math.min(a.method_10264(), b.method_10264()), Math.min(a.method_10260(), b.method_10260()),
                Math.max(a.method_10263(), b.method_10263()), Math.max(a.method_10264(), b.method_10264()), Math.max(a.method_10260(), b.method_10260()));
    }
    public long sizeX() { return (long) maxX - minX + 1; }
    public long sizeY() { return (long) maxY - minY + 1; }
    public long sizeZ() { return (long) maxZ - minZ + 1; }
    public long volume() { return Math.multiplyExact(Math.multiplyExact(sizeX(), sizeY()), sizeZ()); }
    public boolean contains(class_2338 p) { return p.method_10263() >= minX && p.method_10263() <= maxX && p.method_10264() >= minY && p.method_10264() <= maxY && p.method_10260() >= minZ && p.method_10260() <= maxZ; }
    public Cuboid shrinkTo(long maxBlocks) {
        if (maxBlocks < 1 || volume() <= maxBlocks) return this;
        long footprint = sizeX() * sizeZ();
        if (footprint <= maxBlocks) {
            int keptY = (int)Math.max(1, maxBlocks / footprint);
            return new Cuboid(minX, maxY - keptY + 1, minZ, maxX, maxY, maxZ);
        }
        long keptX = Math.max(1, Math.min(sizeX(), maxBlocks / Math.max(1, sizeZ())));
        long keptZ = Math.max(1, Math.min(sizeZ(), maxBlocks / keptX));
        return new Cuboid(minX, maxY, minZ, minX + (int)keptX - 1, maxY, minZ + (int)keptZ - 1);
    }
}
