package dev.flatmine;

import dev.flatmine.common.Cuboid;
import dev.flatmine.network.FlatMinePayloads;
import dev.flatmine.server.*;
import java.util.*;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.networking.v1.*;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2338;
import net.minecraft.class_3218;
import net.minecraft.class_3222;

public final class FlatMine implements ModInitializer {

    private static final Map<UUID, SelectionState> SEL = new HashMap<>();
    private static final Map<UUID, Cuboid> PENDING = new HashMap<>();

    @Override
    public void onInitialize() {
        PayloadTypeRegistry.playC2S().register(FlatMinePayloads.Select.ID, FlatMinePayloads.Select.CODEC);
        PayloadTypeRegistry.playC2S().register(FlatMinePayloads.Action.ID, FlatMinePayloads.Action.CODEC);
        PayloadTypeRegistry.playS2C().register(FlatMinePayloads.Status.ID, FlatMinePayloads.Status.CODEC);

        ServerPlayNetworking.registerGlobalReceiver(FlatMinePayloads.Select.ID, (payload, context) -> 
            context.server().execute(() -> select(context.player(), payload.pos()))
        );

        ServerPlayNetworking.registerGlobalReceiver(FlatMinePayloads.Action.ID, (payload, context) -> 
            // ĐÃ SỬA: Bổ sung payload.destroyDrops() để nhận cờ tiêu hủy
            context.server().execute(() -> action(context.player(), payload.action(), payload.maxBlocks(), payload.destroyDrops()))
        );

        MiningJobManager.init();
    }

    static boolean validTool(class_1799 stack) {
        return stack.method_31574(class_1802.field_8647) || stack.method_31574(class_1802.field_8387) || 
               stack.method_31574(class_1802.field_8403) || stack.method_31574(class_1802.field_8335) || 
               stack.method_31574(class_1802.field_8377) || stack.method_31574(class_1802.field_22024) || 
               stack.method_31574(class_1802.field_8876) || stack.method_31574(class_1802.field_8776) || 
               stack.method_31574(class_1802.field_8699) || stack.method_31574(class_1802.field_8322) || 
               stack.method_31574(class_1802.field_8250) || stack.method_31574(class_1802.field_22023);
    }

    static void select(class_3222 p, class_2338 pos) {
        if (!(p.method_37908() instanceof class_3218 w) || 
            !p.field_13974.method_14267() || 
            !validTool(p.method_6047()) || 
            !w.method_24794(pos) || 
            !w.method_22340(pos) || 
            InteractiveBlocks.isInteractive(w, pos)) {
            return;
        }

        SelectionState s = SEL.computeIfAbsent(p.method_5667(), u -> new SelectionState());

        if (s.first == null || s.dimension != w.method_27983()) {
            s.clear();
            s.dimension = w.method_27983();
            s.first = pos.method_10062();
            send(p, 1, s.first, s.first, 1L, 0);
            return;
        }

        s.second = pos.method_10062();
        Cuboid c = Cuboid.of(s.first, s.second);
        PENDING.put(p.method_5667(), c);
        int remaining = p.method_6047().method_7936() - p.method_6047().method_7919();
        send(p, 2, s.first, s.second, c.volume(), remaining);
    }

    // ĐÃ SỬA: Thêm tham số 'boolean destroyDrops' vào hàm action
    static void action(class_3222 p, int a, long max, boolean destroyDrops) {
        if (a == 0) {
            cancel(p);
            return;
        }

        Cuboid c = PENDING.get(p.method_5667());
        SelectionState s = SEL.get(p.method_5667());

        if (c == null || s == null || s.dimension != p.method_37908().method_27983() || !validTool(p.method_6047())) {
            return;
        }

        if (a == 2) {
            c = c.shrinkTo(Math.max(1, max));
        }

        if (a == 1 || a == 2) {
            PENDING.put(p.method_5667(), c);
            send(p, 3, new class_2338(c.minX(), c.minY(), c.minZ()), new class_2338(c.maxX(), c.maxY(), c.maxZ()), c.volume(), p.method_6047().method_7936() - p.method_6047().method_7919());
            
            // Nếu người chơi chọn đào ngay (Gửi trực tiếp lúc này)
            // (Thường bạn sẽ để Client gọi một action nữa là 3, nhưng ở đây mình giả định bạn muốn xử lý như logic cũ)
            // Ở file ConfirmScreen.java vừa sửa, chúng ta đã gửi action = 1 hoặc 2
            
            // Xóa ở PENDING trước khi bắt đầu
            PENDING.remove(p.method_5667());
            // ĐÃ SỬA: Truyền biến destroyDrops vào MiningJobManager
            MiningJobManager.startJob(p, (class_3218) p.method_37908(), c, destroyDrops);
            return;
        }

        // Logic cũ (dự phòng)
        if (a == 3) {
            MiningJobManager.startJob(p, (class_3218) p.method_37908(), c, destroyDrops);
            PENDING.remove(p.method_5667());
            send(p, 4, new class_2338(c.minX(), c.minY(), c.minZ()), new class_2338(c.maxX(), c.maxY(), c.maxZ()), c.volume(), 0);
        }
    }

    static void cancel(class_3222 p) {
        MiningJobManager.cancelJob(p);
        SEL.computeIfAbsent(p.method_5667(), u -> new SelectionState()).clear();
        PENDING.remove(p.method_5667());
        send(p, 0, class_2338.field_10980, class_2338.field_10980, 0L, 0);
    }

    static void send(class_3222 p, int k, class_2338 a, class_2338 b, long n, int d) {
        ServerPlayNetworking.send(p, new FlatMinePayloads.Status(k, a, b, n, d));
    }
}