package dev.flatmine.render;
import dev.flatmine.client.ClientState; import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.class_1921;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_4588;
import net.minecraft.class_761;
public final class SelectionRenderer {
 public static void render(WorldRenderContext c){if(ClientState.a==null)return;var cam=c.camera().method_19326();var b=ClientState.b==null?ClientState.a:ClientState.b;double minX=Math.min(ClientState.a.method_10263(),b.method_10263())-cam.field_1352,minY=Math.min(ClientState.a.method_10264(),b.method_10264())-cam.field_1351,minZ=Math.min(ClientState.a.method_10260(),b.method_10260())-cam.field_1350,maxX=Math.max(ClientState.a.method_10263(),b.method_10263())+1-cam.field_1352,maxY=Math.max(ClientState.a.method_10264(),b.method_10264())+1-cam.field_1351,maxZ=Math.max(ClientState.a.method_10260(),b.method_10260())+1-cam.field_1350;var vc=c.consumers().getBuffer(class_1921.method_23594());class_761.method_22982(c.matrixStack(),vc,new class_238(minX,minY,minZ,maxX,maxY,maxZ),1,1,1,1);}
 private SelectionRenderer(){}
}
